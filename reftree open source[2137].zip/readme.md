### setup

http://redmine.ilosgroup.com/projects/reftree/wiki/Reftree

Installare:

Git https://git-scm.com/downloads

Node (v8 LTS) https://nodejs.org/en/download/

Farti un account su https://bitbucket.org/product

Una volta fatto quel account i ti posso dare il diritto di accesso al repository git

Quando hai accesso al repository vai alla dirctory dove voi mettere l’applicativo.

Apri il cmd in qulla Directory e metti:

git clone https://bitbucket.org/ilosflorian/aequa.git

rinominare il file config/example.js in index.js e mettere la connectionString e secret (random string lungo) apposto.

Cmd:

cd aequa

npm install -g pm2

npm install

pm2 start pm2.yml

pm2 save

configurare iis come reverse Proxy e puntare a localhost:3000

https://blogs.msdn.microsoft.com/friis/2016/08/25/setup-iis-with-url-rewrite-as-a-reverse-proxy-for-real-world-apps/

cosi potete aggiungere https a quel sito tramite iis

### Names of storeds

aequa_register - throws error if registration failes - input nodes: codiceImmobiliare, codiceFiscale, numeroCellulare
aequa_login - throws error if login fails - input nodes: codiceFiscale, password
aequa_data - returns grid data (table) and config (table) - input nodes: gridName - user node
aequa_grids - returns grids (table) - input nodes: gridName - user node
aequa_save_data
aequa_download
aequa_forgot_password

### Stored input

every sore gets an xml named xmlInput as input formed in the following way

<root>
  <input> <-- input node contains user input data
    <data1>sampleCode</data1>
    <data2>some Data</data2>
  </input>
  <user> <-- user node contains user info if user is authenticated, if user is not authenticated this node is missing
    <codiceFiscale>somecodice</codiceFiscale>
  </user>
</root>


### how to use iis as reverse proxy

https://blogs.msdn.microsoft.com/friis/2016/08/25/setup-iis-with-url-rewrite-as-a-reverse-proxy-for-real-world-apps/