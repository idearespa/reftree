module.exports = {
    secret: 'zNyVgCR380bNPRoKFsND4rezRgAabKCi8UngCruQsByaHMRBI2tyPb30dJdkVs3cWDknllbmMkYS8k3OtkiO33zW73yUrslikupRP0kYo45VCLxGt5ws16vy8IuRh5aDSNxjLxVtiyPwYOBrWYSHt9gaIdVFjzJfIJZbjkYWVErQWv5t7ylei8TXYCnJdq1FPPNmdvj4OesCVqiodcllyYUOTxB8OZ5SfL07e2Hkb3V50wjM2zr4wfg9xV',
    connectionString: {
        user: '',
        password: '',
        server: '',
        port: '51413',
        database: 'aequa'
    }
};