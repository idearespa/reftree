// create a file index.js with the following content, replaced with your settings

module.exports = {
    secret: 'someverylongsecret',
    connectionString: {
        user: 'sa',
        password: '',
        server: '',
        port: '',
        database: ''
    }
};