const express = require('express');
const router = express.Router();
const onlyLoggedUsers = require('connect-ensure-login').ensureLoggedIn();

const stored = require('../db/stored');
const controllerHelper = require('../tools/controllerHelper');

module.exports = function () {
    router.use(onlyLoggedUsers);

    router.get('/grids', async function (req, res) {
        try {
            let result = await getButtons(req.user);
            let jsonResponse = { data: result.recordset };
            res.json(jsonResponse);
        }
        catch (e) {
            controllerHelper.handleError(e, res);
        }
    });

    router.get('/grids/:gridName/data', async function (req, res) {
        try {
            let data = Object.assign(req.query, { gridName: req.params.gridName });
            let result = await getData(req.user, data);
            let jsonResponse = { data: result.recordset };
            if (result.recordsets.length === 2 && result.recordsets[1].length && result.recordsets[1][0].config)
                jsonResponse.config = JSON.parse(result.recordsets[1][0].config);
            if (result.recordsets.length === 2 && result.recordsets[1].length && result.recordsets[1][0].buttons)
                jsonResponse.buttons = result.recordsets[1][0].buttons;
            if (result.recordsets.length === 2 && result.recordsets[1].length && result.recordsets[1][0].title)
                jsonResponse.title = result.recordsets[1][0].title;
            res.json(jsonResponse);
        }
        catch (e) {
            controllerHelper.handleError(e, res);
        }
    });

    router.post('/data', async function (req, res) {
        try {
            let result = await stored.execute('aequa_save_data', req.user, req.body);
            return res.json(result);
        }
        catch (e) {
            controllerHelper.handleError(e, res);
        }
    });

    router.get('/download', async function (req, res) {
        try {
            let result = await stored.execute('aequa_download', req.user, req.query);
            if (result.recordset.length) {
                let file = result.recordset[0];
                res.set({
                    'Content-Length': file.size_in_bytes,
                    'Content-Disposition': `attachment; filename="${file.name}"`
                });
                return res.end(file.file);
            }
            res.status(400);
            res.end();
        }
        catch (e) {
            controllerHelper.handleError(e, res);
        }
    });

    router.post('/account', async function (req, res) {
        try {
            let result = await stored.execute('aequa_update_account', req.user, req.body);
            return res.json(result.recordset.length ? result.recordset[0] : { message: 'ok' });
        }
        catch (e) {
            controllerHelper.handleError(e, res);
        }
    });

    return router;
};

function getData (user, data) {
    return stored.execute('aequa_data', user, data);
}

function getButtons (user) {
    return stored.execute('aequa_grids', user);
}
