var express = require('express');
var router = express.Router();

const onlyLoggedUsers = require('connect-ensure-login').ensureLoggedIn();

module.exports = function () {
    router.get('/backend.html', onlyLoggedUsers, setNoCacheHeader);
    router.get('/grid.html', onlyLoggedUsers, setNoCacheHeader);
    router.get('/communicate.html', onlyLoggedUsers, setNoCacheHeader);
    router.get('/account.html', onlyLoggedUsers, setNoCacheHeader);
    return router;
};

function setNoCacheHeader (req, res, next) {
    res.set('Cache-Control', 'no-store');
    next();
}