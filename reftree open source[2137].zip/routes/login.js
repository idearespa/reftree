var express = require('express');
var router = express.Router();

const stored = require('../db/stored');
const controllerHelper = require('../tools/controllerHelper');

module.exports = function (app, passport) {
    router.get('/login', function (req, res) {
        res.redirect('/login.html');
    });

    router.post(
        '/login'
        , function (req, res, next) {
            passport.authenticate('local', function (error, user) {
                if (error)
                    controllerHelper.handleError(error, res);
                else {
                    req.login(user, error => {
                        if (error)
                            controllerHelper.handleError(error, res);
                        else
                            res.json({ redirect: '/backend.html'});
                    });
                }
            })(req, res, next);
        }
    );

    router.get('/logout', function (req, res) {
        req.logout();
        res.redirect('/');
    });

    router.post(
        '/register'
        , async function (req, res) {
            try {
                let result = await register(req.body);
                res.json({ redirect: '/registration-complete.html'});
            }
            catch (e) {
                controllerHelper.handleError(e, res);
            }
        }
    );

    router.post(
        '/forgot'
        , async function (req, res) {
            try {
                let result = await stored.execute('aequa_forgot_password', null, req.body);
                res.json({ type: 'success', message: result.length ? result[0].message : 'Inviato SMS con la nuova password'});
            }
            catch (e) {
                controllerHelper.handleError(e, res);
            }
        }
    );

    return router;
};

function register (data) {
    return stored.execute('aequa_register', null, data);
}