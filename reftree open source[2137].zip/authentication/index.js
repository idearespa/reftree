const passport = require('passport');
const Strategy = require('passport-local').Strategy;
const session = require('express-session');

const config = require('../config');
const sql = require('../db');
const MssqlStorage = require('./storage');
const stored = require('../db/stored');

const storage = new MssqlStorage({
    client: sql,
    sessionTableName: 'passport_sessions'
});

passport.use(
    new Strategy(
        {
            usernameField: 'codiceFiscale'
        }
        , async function (codiceFiscale, password, done) {
            try {
                let user = {
                    codiceFiscale,
                    password
                };
                await stored.execute('aequa_login', null, user);
                delete user.password;
                done(null, user);
            }
            catch (e) {
                done(e);
            }
        }
    )
);

passport.serializeUser(function (user, done) {
    done(null, user);
});

passport.deserializeUser(function (user, done) {
    done(null, user);
});

module.exports = {
    init: app => {
        app.use(session({
            secret: config.secret,
            saveUninitialized: false,
            resave: true,
            store: storage
        }));
        app.use(passport.initialize());
        app.use(passport.session());
        return passport;
    }
};
