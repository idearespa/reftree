

module.exports = class MssqlStorage extends require('express-session').Store {

    constructor (options) {
        super();
        this.options = options;
        this.client = options.client;
        this.sessionTableName = options.sessionTableName || 'passport_sessions';
        if (!options.client)
            throw new Error('hand in a client');
        this.emit('connected');
        this.createSessionTableIfNotExists();
    }

    async createSessionTableIfNotExists () {
        let tableInfo = this.sessionTableName.split('.');
        let result = await this.client
            .request()
            .query(`SELECT * 
                FROM INFORMATION_SCHEMA.TABLES 
                WHERE TABLE_SCHEMA = '${tableInfo.length === 2 ? tableInfo[0] : 'dbo'}' 
                AND  TABLE_NAME = '${tableInfo.length === 2 ? tableInfo[1] : tableInfo[0]}'`
            );
        if (!result.recordset.length)
            return this.createSessionTable();
    }

    createSessionTable () {
        return this.client
            .request()
            .batch(`CREATE TABLE ${this.sessionTableName}
                (
                    [key] nvarchar(255) not null,
                    [session] nvarchar(2000),
                    [created_at] datetime not null default CURRENT_TIMESTAMP,
                    [updated_at] datetime not null default CURRENT_TIMESTAMP,
                    CONSTRAINT [key_unique] UNIQUE ([key])
                )`);
    }

    async destroy (key, callback) {
        try {
            await this.client
                .request()
                .input('key', key)
                .query(`DELETE FROM ${this.sessionTableName} WHERE [key] = @key`);
            callback();
        }
        catch (e) {
            callback(e);
        }
    }

    async get (key, callback) {
        try {
            let result = await this.client
                .request()
                .input('key', key)
                .query(`SELECT session FROM ${this.sessionTableName} WHERE [key] = @key`);
            if (result.recordset.length)
                callback(null, JSON.parse(result.recordset[0].session));
            else
                callback();
        }
        catch (e) {
            callback(e);
        }
    }

    async set (key, session, callback) {
        try {
            let record = await this.getRecord(key);
            if (!record) {
                await this.client
                    .request()
                    .input('key', key)
                    .input('session', JSON.stringify(session))
                    .input('created_at', new Date())
                    .query(`INSERT INTO ${this.sessionTableName} ([key], created_at, session) values (@key, @created_at, @session)`);
            }
            else {
                await this.client
                    .request()
                    .input('key', key)
                    .input('session', JSON.stringify(session))
                    .input('updated_at', new Date())
                    .query(`UPDATE ${this.sessionTableName} SET updated_at = @updated_at, session = @session WHERE [key] = @key`);
            }
            callback();
        }
        catch (e) {
            callback(e);
        }
    }

    async getRecord (key) {
        return this.client
            .request()
            .input('key', key)
            .query(`SELECT * FROM ${this.sessionTableName} WHERE [key] = @key`)
            .then(result => {
                if (result.recordset.length)
                    return result.recordset[0];
                return null;
            });
    }

    touch (key, session, callback) {
        this.set(key, session, callback);
    }

    async clear (callback) {
        try {
            await this.client
                .request()
                .query(`DELETE FROM ${this.sessionTableName}`);
            callback();
        }
        catch (e) {
            callback(e);
        }
    }

    async all (callback) {
        try {
            let result = await this.client
                .request()
                .query(`SELECT session FROM ${this.sessionTableName}`);
            let sessions = result.recordset.map(record => {
                return JSON.parse(record.session);
            });
            callback(null, sessions);
        }
        catch (e) {
            callback(e);
        }
    }

    async length (callback) {
        try {
            let result = await this.client
                .request()
                .query(`SELECT COUNT(*) AS count FROM ${this.sessionTableName}`);
            callback(null, result.recordset[0].count);
        }
        catch (e) {
            callback(e);
        }
    }

};