export function getGridName() {
    let gridName = /gridName=([^&]*)/.exec(document.location.search);
    if (gridName.length == 2)
        gridName = gridName[1];
    else
        gridName = null;
    return gridName;
};

export function getObject () {
    let obj = {};
    return document.location.search
        .substring(1)
        .split('&')
        .map(part => {
            let parts = part.split('=');
            obj[parts[0]] = parts[1] || null;
        });
    return obj;
}