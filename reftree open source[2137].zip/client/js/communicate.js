import { h, app } from 'hyperapp';
import { notifications } from './notifications';
import { getGridName } from './querystring';
const $ = require('jquery');

const state = {
    gridName: getGridName(),
    busy: false,
    data: {}
};

const actions = {
    setData: data => ({ data }),
    send: event => (state, actions) => {
        actions.setBusy(true);
        event.preventDefault();
        let form = $('#communication-form');
        let data = form.serializeArray().reduce(function(obj, item) {
            obj[item.name] = item.value;
            return obj;
        }, {});
        notifications.removeFirstNotification();
        $.post('/api/data', data)
            .then(
                result => {
                    notifications.addNotification({message: result.recordset[0].message, type: 'success'});
                    actions.setData({});
                }
                , e => {
                    actions.setData(data);
                    notifications.addNotification(e.responseJSON);
                }
            )
            .always(() => actions.setBusy(false))
    },
    setBusy: isBusy => ({ busy: isBusy })
};


const view = (state, actions) => {
    return (
        <div>
            <p><a class="btn btn-secondary" href={`/grid.html?gridName=${state.gridName}`}>Indietro</a></p>
            {!state.busy
                ?
                <div>
                    <form id="communication-form" action="/api/data" method="POST" onsubmit={actions.send}>
                        <h1 class="h3 mb-3 font-weight-normal">Communicazione</h1>
                        <div class="form-group">
                            <label for="description" class="sr-only">descrizione</label>
                            <input name="description" type="text" id="description" class="form-control" placeholder="descrizione" value={state.data.description} required autofocus />
                        </div>
                        <div class="form-group">
                            <label for="text">testo</label>
                            <textarea name="text" class="form-control" id="text" rows="10" value={state.data.text}></textarea>
                        </div>
                        <input style={{display: 'none'}} name="formName" value="communication" />
                        <button type="submit" class="btn btn-primary mb-2">Ok</button>
                    </form>
                </div>
                : <div class="text-center"><i class="fas fa-spinner fa-pulse fa-5x"></i></div>
            }
        </div>
    )
};

let theActions = app(state, actions, view, document.getElementById('main'));