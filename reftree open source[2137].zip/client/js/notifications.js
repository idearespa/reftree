import { h, app } from 'hyperapp';
let $ = require('jquery');

const state = {
    class: 'alert fade show alert-',
    defaultType: 'danger',
    notifications: [],
};

const actions = {
    addNotification: notification => state => {
        let notifications = state.notifications.slice();
        notifications.push(notification);
        // showNotification(state.notifications[0]);
        return { notifications };
    },
    removeFirstNotification: () => state => {    
        state.notifications.shift();
        // if (state.notifications.length)
        //     showNotification(state.notifications[0]);
        return state.notifications;
    }
};

const view = (state, actions) => {
    return (
        <div class="container">
            {state.notifications.map(notification => (
                <div
                    // onremove={
                    //     (el, done) => {
                    //         $(el).removeClass('show');
                    //         setTimeout(done, 300);
                    //     }
                    // }
                    class={state.class + (notification.type || state.defaultType)}
                    role="alert"
                >
                    {state.notifications[0].message}
                </div>
                )
            )}
        </div>
    )
};

let theActions = app(state, actions, view, document.getElementById('notifications'));

export { theActions as notifications };

// let timeout = null;
// function showNotification (notification) {
//     if (timeout === null) {
//         timeout = setTimeout(() => {
//             timeout = null;
//             theActions.removeFirstNotification();
//         }, 5000);
//     }
// }