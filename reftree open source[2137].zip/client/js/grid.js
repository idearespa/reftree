import { h, app } from 'hyperapp';
import { DataTable } from './DataTable';
import { notifications } from './notifications';
import { getGridName } from './querystring';
let $ = require('jquery');

const state = {
    config: null,
    requestFailed: false,
};

const actions = {
    setConfig: config => state => {
        return { config: config };
    },
    setRequestFailed: () => ({requestFailed: true})
};

const addHtml = html => element => {
    if (html)
        element.innerHTML = html;
};

const view = (state, actions) => {
    return (
        <div>
            <p><a class="btn btn-secondary" href="/backend.html">Menu principale</a>{state.config && state.config.buttons ? <span oncreate={addHtml(state.config.buttons)}></span> : ''}</p>
            {state.config
                ? <DataTable config={state.config} />
                : state.requestFailed
                    ? ''
                    : <div class="text-center"><i class="fas fa-spinner fa-pulse fa-5x"></i></div>
            }
        </div>
    )
};

let theActions = app(state, actions, view, document.getElementById('main'));

let language = {
    "decimal":        "",
    "emptyTable":     "Nessun dato presente nella tabella",
    "info":           "Vista da _START_ a _END_ di _TOTAL_ elementi",
    "infoEmpty":      "Vista da 0 a 0 di 0 elementi",
    "infoFiltered":   "(filtrati da _MAX_ elementi totali)",
    "infoPostFix":    "",
    "thousands":      ".",
    "lengthMenu":     "Visualizza _MENU_ elementi",
    "loadingRecords": "Caricamento...",
    "processing":     "Elaborazione...",
    "search":         "Cerca:",
    "zeroRecords":    "La ricerca non ha portato alcun risultato.",
    "paginate": {
        "first":      "Inizio",
        "last":       "Fine",
        "next":       "Successivo",
        "previous":   "Precedente"
    },
    "aria": {
        "sortAscending":  ": attiva per ordinare la colonna in ordine crescente",
        "sortDescending": ": attiva per ordinare la colonna in ordine decrescente"
    }
};

let gridName = getGridName();
let getParams 
if (gridName) {
        let result = $.getJSON(`/api/grids/${gridName}/data${document.location.search}`)
            .then(
                result => {
                    let config = { columns: [] };
                    if (result.config)
                        config = result.config;
                    config.language = language;
                    config.data = [];
                    if (result.data && result.data.length) {
                        if (!result.config) {
                            for (let key in result.data[0]) {
                                if (result.data[0].hasOwnProperty(key)) {
                                    config.columns.push({ name: key, data: key });
                                }
                            }
                        }
                        config.data = result.data;
                    }
                    let columnsLength = config.columns.length;
                    let dateColumns = [];
                    config.columns = config.columns.map(column => {
                        if (column.type === 'date' || column.type === 'datetime') {
                            dateColumns.push(column.data);
                            column.render = data => {
                                let dateString;
                                if (column.type === 'datetime')
                                    dateString = new Date(data).toLocaleString("it-IT");
                                else
                                    dateString = new Date(data).toLocaleDateString("it-IT");
                                return dateString.replace(/\b[\d](?!\d)/g, "0$&");
                            }
                            column.orderData = columnsLength++;
                        }
                        return column;
                    });
                    if (config.data.length && dateColumns.length) {
                        dateColumns.map(column => {
                            config.columns.push({
                                data: column + "__sort",
                                visible: false,
                                searchable: false
                            });
                        });
                        config.data = config.data.map(record => {
                            dateColumns.map(column => record[column + "__sort"] = record[column]);
                            return record;
                        });
                    }
                    if (result.buttons)
                        config.buttons = result.buttons;
                    if (result.title)
                        $('title').html(result.title);
                    config.responsive = true;
                    theActions.setConfig(config);    
                }
                , e => {
                    notifications.addNotification(e.responseJSON);
                    theActions.setRequestFailed();
                }
        );
}