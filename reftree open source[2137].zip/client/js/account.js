import { h, app } from 'hyperapp';
import { notifications } from './notifications';
let $ = require('jquery');

const state = {
    
};

const actions = {
    submit: event => (state, actions) => {
        notifications.removeFirstNotification();        
        event.preventDefault();
        let form = $('form');
        let data = form.serializeArray().reduce(function(obj, item) {
            obj[item.name] = item.value;
            return obj;
        }, {});
        $.post('/api/account', data)
            .then(
                result => {
                    notifications.addNotification(Object.assign({type: 'success'}, result));
                },
                error => {
                    notifications.addNotification(error.responseJSON);
                }
            );
    }
};
  
const view = (state, actions) => (
    <form class="form-signin offset-4 col-4 mt-4" onsubmit={actions.submit}>
        <label for="numeroCellulare" class="sr-only">Numero cellulare</label>
        <div class="input-group">
            <div class="input-group-prepend">
                <div class="input-group-text">+39</div>
            </div>
            <input name="numeroCellulare" type="text" id="numeroCellulare" class="form-control" placeholder="Numero cellulare" required />
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Ok</button>
    </form>
);
  
let theActions = app(state, actions, view, document.getElementById('main'));