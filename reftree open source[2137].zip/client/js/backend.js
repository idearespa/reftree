import { h, app } from 'hyperapp';
import { GridButton } from './GridButton.js';
import { notifications } from './notifications';
let $ = require('jquery');

const state = {
    showGrid: false,
    buttons: []
};

const actions = {
    setButtons (buttons) {
        return { buttons: buttons };
    },
    delete: index => state => {
        let buttons = state.buttons.slice();
        buttons.splice(index, 1);
        return { buttons: buttons };
    },
};
  
const view = (state, actions) => (
    <div class="row">
        {state.buttons.map((buttonInfo, i) => (
            <GridButton buttonInfo={buttonInfo} index={i} />
        ))}
    </div>
);
  
let theActions = app(state, actions, view, document.getElementById('main'));

$.getJSON('/api/grids')
    .then(
            result => {
                theActions.setButtons(result.data);
            }
            , e => notifications.addNotification(e.responseJSON)
    );