import { h, app } from 'hyperapp';
import { notifications } from './notifications';
let $ = require('jquery');

const state = {
    
};

const actions = {
    submit: event => (state, actions) => {
        notifications.removeFirstNotification();        
        event.preventDefault();
        let form = $('form');
        let data = form.serializeArray().reduce(function(obj, item) {
            obj[item.name] = item.value;
            return obj;
        }, {});
        $.post('/register', data)
            .then(
                result => {
                    window.location = result.redirect;
                },
                error => {
                    notifications.addNotification(error.responseJSON);
                }
            );
    }
};
  
const view = (state, actions) => (
    <form class="form-signin" method="POST" action="/register" onsubmit={actions.submit}>
        <img src="/images/ref.png" alt="Reftree" title="Reftree" class="img-thumbnail mb-2" />
        <label for="codiceImmobiliare" class="sr-only">Codice Unità immobiliare</label>
        <input name="codiceImmobiliare" type="text" id="codiceImmobiliare" class="form-control" placeholder="Codice Unità immobiliare" required autofocus />
        <label for="codiceFiscale" class="sr-only">Codice Fiscale</label>
        <input name="codiceFiscale" type="text" id="codiceFiscale" class="form-control" placeholder="Codice Fiscale" required />
        <label for="numeroCellulare" class="sr-only">Numero cellulare</label>
        <div class="input-group">
            <div class="input-group-prepend">
                <div class="input-group-text">+39</div>
            </div>
            <input name="numeroCellulare" type="text" id="numeroCellulare" class="form-control" placeholder="Numero cellulare" required />
        </div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Registra</button>
    </form>
);
  
let theActions = app(state, actions, view, document.getElementById('main'));