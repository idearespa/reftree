let $ = require('jquery');
require('datatables.net-bs4')(window, $);
require('datatables.net-responsive')(window, $);

import { h } from 'hyperapp';

function init(config) {
    let id = 'table-' + (Math.random() + "").substring(2);
    setTimeout(() => {
        let table = $('#' + id);
        table.on('init.dt', function () {
            let lengthDrop = table.closest('.dataTables_wrapper').find('.dataTables_length').parent();
            lengthDrop.removeClass('col-md-6');
            lengthDrop.addClass('col-md-1');
        });
        table.DataTable(config);
    });
    return id;
}

export const DataTable = ({ config }) => {
    let id = init(config);
    return (
        <table class="table" id={id}>
            <thead>
                <tr>
                    {config
                        .columns
                        .map(column => (
                            <th>{column.name}</th>
                        ))
                    }
                </tr>
            </thead>
        </table>
    )
};