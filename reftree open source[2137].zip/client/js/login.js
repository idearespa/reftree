import { h, app } from 'hyperapp';
import { notifications } from './notifications';
let $ = require('jquery');

const state = {
    
};

const actions = {
    submit: event => (state, actions) => {
        notifications.removeFirstNotification();        
        event.preventDefault();
        let form = $('form');
        let data = form.serializeArray().reduce(function(obj, item) {
            obj[item.name] = item.value;
            return obj;
        }, {});
        $.post('/login', data)
            .then(
                result => {
                    window.location = result.redirect;
                },
                error => {
                    notifications.addNotification(error.responseJSON);
                }
            );
    }
};
  
const view = (state, actions) => (
    <form class="form-signin" method="POST" action="/login" onsubmit={actions.submit}>
        <div id="notification"></div>
        <img src="/images/ref.png" alt="Reftree" title="Reftree" class="img-thumbnail mb-2" />
        <label for="inputEmail" class="sr-only">Name</label>
        <input name="codiceFiscale" type="text" id="inputEmail" class="form-control" placeholder="Name" required autofocus />
        <label for="inputPassword" class="sr-only">Password</label>
        <input name="password" type="password" id="inputPassword" class="form-control" placeholder="Password" required />
        <div class="mb-2"><a href="/register.html">Registrati</a></div>
        <div class="mb-2"><a href="/forgot.html">Ho dimenticato la password</a></div>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Entra</button>
    </form>
);
  
let theActions = app(state, actions, view, document.getElementById('main'));