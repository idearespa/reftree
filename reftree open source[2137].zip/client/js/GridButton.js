import { h } from 'hyperapp';

export const GridButton = ({buttonInfo, index, onclick}) => (
    <div class="col-md-4">
        <h2>{buttonInfo.title}</h2>
        <p><a class="btn btn-secondary" href={'/grid.html?gridName=' + buttonInfo.gridName}>{buttonInfo.description}</a></p>
    </div>
);
