
module.exports = function () {
    //init db connection
    return require('./db/connection').connecting;
};