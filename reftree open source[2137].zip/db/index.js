const connection = require('./connection');

module.exports = connection.pool;