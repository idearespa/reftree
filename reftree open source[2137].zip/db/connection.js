const sql = require('mssql');

const config = require('../config');
let connected;
let connectionFailed;

let connection = {
    pool: null,
    connecting: new Promise((resolve, reject) => {
        connected = resolve;
        connectionFailed = reject;
    }),
    ready: false
};

(async function connect () {
    try {
        connection.pool = await sql.connect(config.connectionString);
        connected();
        connection.ready = true;
    }
    catch (e) {
        connectionFailed(e);
    }
})();

module.exports = connection;