const sql = require('.');
const mssql = require('mssql');
const xml = require('../tools/xml');

module.exports = {
    execute (storedName, user = null, obj = null) {
        let xmlInput = xml.stringify(user, obj);
        return sql.request()
            .input('xmlInput', mssql.Xml, xmlInput)
            .execute(storedName);
    }
};