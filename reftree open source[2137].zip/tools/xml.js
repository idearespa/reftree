const EasyXml = require('easyxml');

const serializer = new EasyXml({
    rootElement: 'root',
});

module.exports = {
    stringify (user = null, input = null) {
        let obj = {};
        if (user)
            obj.user = user;
        if (input)
            obj.input = input;
        return serializer.render(obj);
    }
};