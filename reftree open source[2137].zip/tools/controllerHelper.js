module.exports = {
    handleError (error, res, options = { shallLog: false, statusCode: 500, redirectToErrorPage: false }) {
        options.statusCode = options.statusCode || 500;
        res.status(options.statusCode);
        if (options.redirectToErrorPage) {
            error.status = options.statusCode;
            res.locals.error = process.env.NODE_ENV !== 'production' ? error : {};
            res.locals.message = error.message;
            res.render('error');
        }
        else {
            res.json({message: error.message});
        }
    }
};